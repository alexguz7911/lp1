from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from .models import productos

def begin(request):
    return HttpResponse("Hola mundo?")

# Create your views here.

def productos(request):
#    return HttpResponse("Hola mundo?")
    misProductos = productos.objects.all().values()
    template = loader.get_template('productos.html')
    context = {
        'misProductos': misProductos,
    }
    return HttpResponse(template.render(context,request))
# Create your views here.