from django.contrib import admin
from .models import productos
#from .models import productos --comentado en clase
# Register your models here.

class productosAdmin(admin.ModelAdmin):
    list_display=('codigoProducto','descripcionProducto', 'estatus')

admin.site.register(productos,productosAdmin)