from django.db import models

class productos(models.Model):
    codigoProducto= models.CharField(max_length=20)
    descripcionProducto = models.CharField(max_length=25)
    estatus = models.BooleanField()
